import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() => runApp(const MitraApp());

class MitraApp extends StatelessWidget {
  const MitraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mitra AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _input = TextEditingController();
  final _tts = FlutterTts();
  final _speech = stt.SpeechToText();
  final List<Map<String, String>> _messages = [];
  String _language = 'English';
  bool _listening = false;
  String _reply = 'Namaste! Main Mitra AI hoon. Aap mujhse kuch bhi pooch sakte ho.';

  @override
  void initState() {
    super.initState();
    _load();
    _messages.add({'from': 'Mitra', 'text': _reply});
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() => _language = p.getString('language') ?? 'English');
  }

  Future<void> _saveLanguage(String value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('language', value);
    setState(() => _language = value);
  }

  String _answer(String text) {
    final q = text.toLowerCase();
    if (q.contains('hello') || q.contains('hi') || q.contains('namaste')) {
      return _language == 'Marathi'
          ? 'नमस्कार! मी Mitra AI आहे. मी तुमची मदत करण्यासाठी तयार आहे.'
          : _language == 'Hindi'
              ? 'नमस्ते! मैं Mitra AI हूँ। मैं आपकी मदद करने के लिए तैयार हूँ।'
              : 'Hello! I am Mitra AI. I am ready to help you.';
    }
    if (q.contains('reminder') || q.contains('yaad') || q.contains('remind')) {
      return _language == 'Marathi'
          ? 'ठीक आहे. तुम्ही Reminder तयार करू शकता.'
          : _language == 'Hindi'
              ? 'ठीक है। आप Reminder बना सकते हैं.'
              : 'Sure. You can create a reminder from the Reminders button.';
    }
    if (q.contains('time')) return 'I can help you plan your schedule and reminders.';
    return _language == 'Marathi'
        ? 'मी तुमचा प्रश्न समजून घेण्याचा प्रयत्न करत आहे. पुढील आवृत्तीत real AI API जोडता येईल.'
        : _language == 'Hindi'
            ? 'मैं आपका सवाल समझने की कोशिश कर रहा हूँ। अगली build में real AI API जोड़ी जा सकती है.'
            : 'I am processing your request. A real AI API can be connected in the next build.';
  }

  Future<void> _send([String? value]) async {
    final text = (value ?? _input.text).trim();
    if (text.isEmpty) return;
    final answer = _answer(text);
    setState(() {
      _messages.add({'from': 'You', 'text': text});
      _messages.add({'from': 'Mitra', 'text': answer});
      _reply = answer;
      _input.clear();
    });
    await _tts.setLanguage(_language == 'Marathi' ? 'mr-IN' : _language == 'Hindi' ? 'hi-IN' : 'en-US');
    await _tts.speak(answer);
  }

  Future<void> _voice() async {
    if (_listening) {
      await _speech.stop();
      setState(() => _listening = false);
      return;
    }
    final ok = await _speech.initialize(
      onStatus: (s) => setState(() => _listening = s == 'listening'),
      onError: (_) => setState(() => _listening = false),
    );
    if (!ok) return;
    setState(() => _listening = true);
    await _speech.listen(
      localeId: _language == 'Marathi' ? 'mr_IN' : _language == 'Hindi' ? 'hi_IN' : 'en_US',
      onResult: (r) {
        _input.text = r.recognizedWords;
        if (r.finalResult) _send(r.recognizedWords);
      },
    );
  }

  void _showReminders() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('⏰ Reminders'),
        content: const Text('Reminder screen ready. Notifications can be connected in the production build.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🤖 Mitra AI'),
        actions: [
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _language,
              items: const [
                DropdownMenuItem(value: 'English', child: Text('EN')),
                DropdownMenuItem(value: 'Hindi', child: Text('हिं')),
                DropdownMenuItem(value: 'Marathi', child: Text('मर')),
              ],
              onChanged: (v) { if (v != null) _saveLanguage(v); },
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (_, i) {
                final m = _messages[i];
                final mine = m['from'] == 'You';
                return Align(
                  alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text('${m['from']}: ${m['text']}'),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: Row(
              children: [
                IconButton(
                  tooltip: 'Voice',
                  onPressed: _voice,
                  icon: Icon(_listening ? Icons.mic : Icons.mic_none),
                ),
                Expanded(
                  child: TextField(
                    controller: _input,
                    onSubmitted: (_) => _send(),
                    decoration: const InputDecoration(
                      hintText: 'Ask Mitra AI...',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: _send,
                  child: const Icon(Icons.send),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Wrap(
              spacing: 8,
              children: [
                ActionChip(label: const Text('⏰ Reminder'), onPressed: _showReminders),
                ActionChip(label: const Text('📝 Note'), onPressed: () => _send('Create a note')),
                ActionChip(label: const Text('📅 Plan'), onPressed: () => _send('Help me plan my day')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
