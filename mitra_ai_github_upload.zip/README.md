# Mitra AI

Mitra AI is a Flutter starter app for Android and iOS.

Included:
- AI-style chat interface
- Voice input (speech-to-text)
- Voice replies (text-to-speech)
- Hindi / Marathi / English selector
- Reminder/Note/Plan quick actions
- Local language preference

Important:
- This starter does NOT put an AI API key inside the mobile app.
- For a production version, connect a secure backend API and notification service.
- The GitHub Actions workflow builds an Android APK automatically.
